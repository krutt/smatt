
# Flags for OP_CHECKCONTRACTVERIFY
CCV_FLAG_CHECK_INPUT: int = -1
CCV_FLAG_IGNORE_OUTPUT_AMOUNT: int = 1
CCV_FLAG_DEDUCT_OUTPUT_AMOUNT: int = 2

# point with provably unknown private key
NUMS_KEY: bytes = bytes.fromhex("50929b74c1a04954b78b4b6035e97a5e078a5a0f28ec96d547bfee9ace803ac0")
