## MATT hub

This folder will contain general purpose, reusable smart contracts that can be used as building blocks for more complex constructions.